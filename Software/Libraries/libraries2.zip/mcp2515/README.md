mcp2515
=======

Macchina library to facilitate CAN functionality with the onboard Microchip MCP2515 CAN controller

This library now shares a common API and base class with due_can and requires a shared base library called can_common. 

It can be found at:
https://github.com/collin80/can_common
