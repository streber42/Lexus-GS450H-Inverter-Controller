Arduino-INA226
==============

INA226 Bi-directional Current/Power Monitor Arduino Library

Tutorials: http://www.jarzebski.pl/arduino/czujniki-i-sensory/cyfrowy-czujnik-pradu-mocy-ina226.html

This library use I2C to communicate, 2 pins are required to interface.
