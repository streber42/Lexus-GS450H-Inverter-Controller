var searchData=
[
  ['synch',['SYNCH',['../_a_d_c___module_8h.html#a6e69c3b8cfd3360af320ac0bcf5b12eeaff3c543e04a7a5d3dac5185b45d12d09',1,'ADC_Module.h']]]
];
