var searchData=
[
  ['license',['LICENSE',['../md_E:_Users_Villanueva_Arduino_libraries_ADC_LICENSE.html',1,'']]]
];
