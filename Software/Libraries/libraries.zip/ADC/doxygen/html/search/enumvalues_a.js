var searchData=
[
  ['very_5fhigh_5fspeed',['VERY_HIGH_SPEED',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2a605020f3fad4a24098fbbb0fa4a293f1',1,'VERY_HIGH_SPEED():&#160;ADC_Module.h'],['../_a_d_c___module_8h.html#a3fc99f48d35189e64d2628def313a15da605020f3fad4a24098fbbb0fa4a293f1',1,'VERY_HIGH_SPEED():&#160;ADC_Module.h']]],
  ['very_5flow_5fspeed',['VERY_LOW_SPEED',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2a5afd4ce3e51232e5889cfd918354ff2d',1,'VERY_LOW_SPEED():&#160;ADC_Module.h'],['../_a_d_c___module_8h.html#a3fc99f48d35189e64d2628def313a15da5afd4ce3e51232e5889cfd918354ff2d',1,'VERY_LOW_SPEED():&#160;ADC_Module.h']]],
  ['vref_5fout',['VREF_OUT',['../_a_d_c___module_8h.html#ac8d2892dc23aba5d30e7013804d3429ba7cfb6990906e489b3f7b7d351fc1c106',1,'ADC_Module.h']]],
  ['vrefh',['VREFH',['../_a_d_c___module_8h.html#ac8d2892dc23aba5d30e7013804d3429ba1f5248caa2d2138480493dd069530462',1,'ADC_Module.h']]],
  ['vrefl',['VREFL',['../_a_d_c___module_8h.html#ac8d2892dc23aba5d30e7013804d3429bab546f9ad5f80e932f2fd1038bbaddaa8',1,'ADC_Module.h']]]
];
