var searchData=
[
  ['channel2sc1aadc0',['channel2sc1aADC0',['../class_a_d_c.html#ab790c1b44b90ff497cbf3e88f4580be8',1,'ADC']]],
  ['channel2sc1aadc1',['channel2sc1aADC1',['../class_a_d_c.html#a756fe8fa6da7ab09cde1f7b27aeffd43',1,'ADC']]]
];
