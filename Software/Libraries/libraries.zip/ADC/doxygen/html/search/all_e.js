var searchData=
[
  ['read',['read',['../class_ring_buffer.html#a8585065af57a71269bc46b30175c8dc8',1,'RingBuffer::read()'],['../class_ring_buffer_d_m_a.html#ac79ee944ee98c4da859c6e5f112022ea',1,'RingBufferDMA::read()']]],
  ['readsingle',['readSingle',['../class_a_d_c.html#aee7423bfcbb03465bb0bd1e3c6474452',1,'ADC::readSingle()'],['../class_a_d_c___module.html#a60d0edc82fd1dbb2e20d090a53718ce2',1,'ADC_Module::readSingle()']]],
  ['readsynchronizedcontinuous',['readSynchronizedContinuous',['../class_a_d_c.html#acd10f3bc117a244e70e53c3489aa97bc',1,'ADC']]],
  ['readsynchronizedsingle',['readSynchronizedSingle',['../class_a_d_c.html#a38d941542bbdbc20c1b9e26a5051094a',1,'ADC']]],
  ['recalibrate',['recalibrate',['../class_a_d_c___module.html#afe8ed6f2a6c811ec3ef2c4aba768982f',1,'ADC_Module']]],
  ['ref_5f1v2',['REF_1V2',['../_a_d_c___module_8h.html#a1edb7e48507f5c04ef3db68b5d5b01c9a77f9ecbcb2044013c35ce1156c14b3a0',1,'ADC_Module.h']]],
  ['ref_5f3v3',['REF_3V3',['../_a_d_c___module_8h.html#a1edb7e48507f5c04ef3db68b5d5b01c9acbdca6103ed9d1895ad7cabeda125dac',1,'ADC_Module.h']]],
  ['ref_5fext',['REF_EXT',['../_a_d_c___module_8h.html#a1edb7e48507f5c04ef3db68b5d5b01c9a5f3cc7cfab06012c0aa6a4b8a5a77161',1,'ADC_Module.h']]],
  ['reseterror',['resetError',['../class_a_d_c.html#aa65014de31051e06a469982ca286496b',1,'ADC::resetError()'],['../class_a_d_c___module.html#abf980784cf468d28fc2cbb94d06be500',1,'ADC_Module::resetError()']]],
  ['ringbuffer',['RingBuffer',['../class_ring_buffer.html',1,'RingBuffer'],['../class_ring_buffer.html#a93b9973de32a836bdf70befaf9d78eed',1,'RingBuffer::RingBuffer()']]],
  ['ringbufferdma',['RingBufferDMA',['../class_ring_buffer_d_m_a.html',1,'RingBufferDMA'],['../class_ring_buffer_d_m_a.html#a37b578fe20ec7e7a361a614f9e9a2a07',1,'RingBufferDMA::RingBufferDMA()']]]
];
