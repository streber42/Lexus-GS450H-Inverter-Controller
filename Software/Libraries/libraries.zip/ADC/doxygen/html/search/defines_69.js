var searchData=
[
  ['internal',['INTERNAL',['../_a_d_c_8h.html#a02c5e2eafaed44878fd8e6c54c8dde4d',1,'ADC.h']]],
  ['internal1v1',['INTERNAL1V1',['../_a_d_c_8h.html#a56000ad2fa885e1acdbb06da63ded9bb',1,'ADC.h']]],
  ['internal1v2',['INTERNAL1V2',['../_a_d_c_8h.html#ade90e2ab8528c36fd37e2c0ae653f704',1,'ADC.h']]]
];
