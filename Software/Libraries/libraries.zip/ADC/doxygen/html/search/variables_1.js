var searchData=
[
  ['b_5fend',['b_end',['../class_ring_buffer_d_m_a.html#a738e6dc1618b83178f42638cd9b58662',1,'RingBufferDMA']]],
  ['b_5fstart',['b_start',['../class_ring_buffer_d_m_a.html#a1145aff44d38f6c8025f28bf082ec8b0',1,'RingBufferDMA']]]
];
