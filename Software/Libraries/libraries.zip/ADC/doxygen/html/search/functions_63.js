var searchData=
[
  ['calibrate',['calibrate',['../class_a_d_c___module.html#a037ab0589e2966cd07292c8186cad83e',1,'ADC_Module']]],
  ['checkdifferentialpins',['checkDifferentialPins',['../class_a_d_c___module.html#a80d29662a1a32a51fec606351685ebaf',1,'ADC_Module']]],
  ['checkpin',['checkPin',['../class_a_d_c___module.html#a9fd95a61d263a9d82918b50e81aee2e9',1,'ADC_Module']]],
  ['continuousmode',['continuousMode',['../class_a_d_c___module.html#a6ff99bbd16cc6526f0a2ba04c3d3ceea',1,'ADC_Module']]]
];
