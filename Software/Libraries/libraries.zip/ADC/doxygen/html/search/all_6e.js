var searchData=
[
  ['num_5fmeasurements',['num_measurements',['../class_a_d_c___module.html#a27fdc83a7dbe3a8c8c24fc4273414256',1,'ADC_Module']]]
];
