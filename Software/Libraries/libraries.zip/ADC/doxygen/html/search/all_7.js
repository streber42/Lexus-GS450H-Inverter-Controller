var searchData=
[
  ['high_5fspeed',['HIGH_SPEED',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2a78f3e093707596168b9993c4f6f8ae10',1,'HIGH_SPEED():&#160;ADC_Module.h'],['../_a_d_c___module_8h.html#a3fc99f48d35189e64d2628def313a15da78f3e093707596168b9993c4f6f8ae10',1,'HIGH_SPEED():&#160;ADC_Module.h']]],
  ['high_5fspeed_5f16bits',['HIGH_SPEED_16BITS',['../_a_d_c___module_8h.html#ac34be55b6924d2fde288f7e176ac62b2ac89070efb9f2a03d57915d92e251f9fd',1,'ADC_Module.h']]]
];
