var searchData=
[
  ['getmaxvalue',['getMaxValue',['../class_a_d_c.html#a45c14b6ec1e956d12f34a99354559a43',1,'ADC::getMaxValue()'],['../class_a_d_c___module.html#af3704819ccda64bae9c13a95a74e70a8',1,'ADC_Module::getMaxValue()']]],
  ['getpdbfrequency',['getPDBFrequency',['../class_a_d_c___module.html#ae113f4168d9dd343f66ecc6e59a245f6',1,'ADC_Module']]],
  ['getpga',['getPGA',['../class_a_d_c.html#aaea8da73b589edbd9e3e501c1e11c398',1,'ADC::getPGA()'],['../class_a_d_c___module.html#a5734a05ce4920be3a2b7fc004a6a14d7',1,'ADC_Module::getPGA()']]],
  ['getresolution',['getResolution',['../class_a_d_c.html#a7280bdee747b978de83923fcfa90cba1',1,'ADC::getResolution()'],['../class_a_d_c___module.html#a58cabc09d41f6aa25319fd514b47c48f',1,'ADC_Module::getResolution()']]]
];
