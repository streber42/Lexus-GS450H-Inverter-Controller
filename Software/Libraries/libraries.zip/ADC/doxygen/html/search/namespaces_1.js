var searchData=
[
  ['vref',['VREF',['../namespace_v_r_e_f.html',1,'']]]
];
